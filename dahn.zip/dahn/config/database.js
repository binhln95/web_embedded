// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': 'ldt',
        'database': "dahn"
    },
	'database': 'dahn',
    'users_table': 'users'
};
